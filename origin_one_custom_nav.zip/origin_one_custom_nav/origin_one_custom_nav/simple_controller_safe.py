#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from rclpy.time import Time

from geometry_msgs.msg import Twist, PoseStamped
from nav_msgs.msg import Path, OccupancyGrid
import tf2_ros
from tf2_ros import TransformException


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


class SimpleController(Node):
    """
    Path-following controller:
      - subscribes to nav_msgs/Path on /custom_plan
      - uses TF to get robot pose in 'map'
      - follows the path with a lookahead controller
      - enforces final orientation at goal
      - publishes cmd_vel on /cmd_vel
      - can request replans if local obstacles block the path
    """

    def __init__(self):
        super().__init__('simple_controller')

        # Parameters
        self.declare_parameter('plan_topic', '/custom_plan')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')

        self.declare_parameter('lookahead_distance', 0.6)
        self.declare_parameter('goal_tolerance', 0.20)
        self.declare_parameter('yaw_tolerance', 0.10)
        self.declare_parameter('linear_gain', 0.7)
        self.declare_parameter('angular_gain', 1.2)
        self.declare_parameter('min_linear_speed', 0.08)      # m/s when far from goal
        self.declare_parameter('max_linear_speed', 0.25)
        self.declare_parameter('max_angular_speed', 1.0)
        self.declare_parameter('max_linear_accel', 0.3)       # m/s^2
        self.declare_parameter('max_angular_accel', 1.5)      # rad/s^2
        self.declare_parameter('allow_reversing', True)

        self.declare_parameter('obstacle_costmap_topic', '/local_costmap/costmap')
        self.declare_parameter('obstacle_check_radius', 0.7)  # m around robot
        self.declare_parameter('obstacle_lethal_cost', 200)   # cost value ~ "very bad"
        self.declare_parameter('obstacle_slowdown_gain', 0.7) # how strongly we slow down

        self.declare_parameter('goal_topic', '/goal_point')
        self.declare_parameter('replan_min_interval', 2.0)            # s, throttle
        self.declare_parameter('progress_distance_threshold', 0.05)   # m
        self.declare_parameter('obstacle_replan_lookahead_distance', 1.5)  # m

        self.plan_topic = self.get_parameter('plan_topic').value
        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.lookahead_distance = float(self.get_parameter('lookahead_distance').value)
        self.goal_tolerance = float(self.get_parameter('goal_tolerance').value)
        self.yaw_tolerance = float(self.get_parameter('yaw_tolerance').value)
        self.linear_gain = float(self.get_parameter('linear_gain').value)
        self.angular_gain = float(self.get_parameter('angular_gain').value)
        self.min_linear_speed = float(self.get_parameter('min_linear_speed').value)
        self.max_linear_speed = float(self.get_parameter('max_linear_speed').value)
        self.max_angular_speed = float(self.get_parameter('max_angular_speed').value)
        self.max_linear_accel = float(self.get_parameter('max_linear_accel').value)
        self.max_angular_accel = float(self.get_parameter('max_angular_accel').value)
        self.allow_reversing = bool(self.get_parameter('allow_reversing').value)

        self.obstacle_costmap_topic = self.get_parameter('obstacle_costmap_topic').value
        self.obstacle_check_radius = float(self.get_parameter('obstacle_check_radius').value)
        self.obstacle_lethal_cost = float(self.get_parameter('obstacle_lethal_cost').value)
        self.obstacle_slowdown_gain = float(self.get_parameter('obstacle_slowdown_gain').value)

        self.goal_topic = self.get_parameter('goal_topic').value
        self.replan_min_interval = float(self.get_parameter('replan_min_interval').value)
        self.progress_distance_threshold = float(self.get_parameter('progress_distance_threshold').value)
        self.obstacle_replan_lookahead_distance = float(
            self.get_parameter('obstacle_replan_lookahead_distance').value
        )

        # TF
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # State
        self.current_path_world = None  # list of (x, y)
        self.current_path_index = 0
        self.goal_yaw = None
        self.travel_start_time = None
        self.last_cmd_time = None
        self.last_v = 0.0
        self.last_omega = 0.0
        self.obstacle_costmap = None
        self.obstacle_costmap_info = None
        self.current_goal_msg = None
        self.last_replan_time = None
        self.last_progress_pose = None

        # Sub / Pub
        self.plan_sub = self.create_subscription(
            Path, self.plan_topic, self.plan_callback, 10
        )
        self.cmd_vel_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)

        self.obstacle_costmap_sub = self.create_subscription(
            OccupancyGrid,
            self.obstacle_costmap_topic,
            self.obstacle_costmap_callback,
            10
        )

        self.goal_sub = self.create_subscription(
            PoseStamped,
            self.goal_topic,
            self.goal_callback,
            10
        )
        self.goal_pub = self.create_publisher(PoseStamped, self.goal_topic, 10)

        # Control loop timer (10 Hz)
        self.control_timer = self.create_timer(0.1, self.control_loop)

        self.get_logger().info(
            f'SimpleController started. '
            f'Listening for Path on "{self.plan_topic}", '
            f'publishing cmd_vel on "{self.cmd_vel_topic}".'
        )

    # ---------- TF helper ----------

    def get_robot_pose_map(self):
        try:
            transform = self.tf_buffer.lookup_transform(
                'map', 'base_link', Time()
            )
        except TransformException as ex:
            self.get_logger().warn(f'Could not transform map -> base_link: {ex}')
            return None
        t = transform.transform.translation
        r = transform.transform.rotation
        x = t.x
        y = t.y
        yaw = yaw_from_quaternion(r)
        return x, y, yaw

    @staticmethod
    def normalize_angle(angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    # ---------- Plan callback ----------

    def plan_callback(self, msg: Path):
        if not msg.poses:
            self.get_logger().warn('Received empty path, stopping.')
            self.current_path_world = None
            self.current_path_index = 0
            self.goal_yaw = None
            self.travel_start_time = None
            self.last_v = 0.0
            self.last_omega = 0.0
            self.last_cmd_time = None
            self.cmd_vel_pub.publish(Twist())
            return

        path_world = []
        for pose_stamped in msg.poses:
            x = pose_stamped.pose.position.x
            y = pose_stamped.pose.position.y
            path_world.append((x, y))

        last_pose = msg.poses[-1].pose
        self.goal_yaw = yaw_from_quaternion(last_pose.orientation)

        self.current_path_world = path_world
        self.current_path_index = 0
        self.travel_start_time = None  # reset timer for new path

        self.get_logger().info(
            f'Received new path with {len(path_world)} waypoints.'
        )

    # ---------- Obstacle costmap helpers ----------

    def obstacle_costmap_callback(self, msg: OccupancyGrid):
        self.obstacle_costmap = list(msg.data)
        self.obstacle_costmap_info = msg.info

    def obstacle_world_to_grid(self, x, y):
        if self.obstacle_costmap_info is None:
            return None
        info = self.obstacle_costmap_info
        res = info.resolution
        origin = info.origin.position
        mx = int((x - origin.x) / res)
        my = int((y - origin.y) / res)
        if 0 <= mx < info.width and 0 <= my < info.height:
            return mx, my
        return None

    def obstacle_cost_at(self, mx, my):
        if self.obstacle_costmap is None or self.obstacle_costmap_info is None:
            return None
        info = self.obstacle_costmap_info
        if not (0 <= mx < info.width and 0 <= my < info.height):
            return None
        idx = my * info.width + mx
        return self.obstacle_costmap[idx]

    def compute_obstacle_slowdown_factor(self, rx, ry):
        if self.obstacle_costmap_info is None or self.obstacle_costmap is None:
            return 1.0

        cell = self.obstacle_world_to_grid(rx, ry)
        if cell is None:
            return 1.0

        mx_center, my_center = cell
        info = self.obstacle_costmap_info
        res = info.resolution

        radius_cells = int(math.ceil(self.obstacle_check_radius / res))
        max_cost = 0.0

        for dx in range(-radius_cells, radius_cells + 1):
            for dy in range(-radius_cells, radius_cells + 1):
                nx = mx_center + dx
                ny = my_center + dy
                if not (0 <= nx < info.width and 0 <= ny < info.height):
                    continue
                if dx * dx + dy * dy > radius_cells * radius_cells:
                    continue

                c = self.obstacle_cost_at(nx, ny)
                if c is None or c < 0:
                    continue
                if c > max_cost:
                    max_cost = c

        if max_cost <= 0.0:
            return 1.0

        cost_ratio = min(max_cost / self.obstacle_lethal_cost, 1.0)
        slowdown = cost_ratio * self.obstacle_slowdown_gain
        factor = max(0.0, 1.0 - slowdown)
        return factor

    # ---------- Replanning helpers ----------

    def goal_callback(self, msg: PoseStamped):
        self.current_goal_msg = msg

    def request_replan(self, reason: str):
        if self.current_goal_msg is None:
            self.get_logger().warn('Cannot request replan: no remembered goal.')
            return

        now = self.get_clock().now()
        if self.last_replan_time is not None:
            dt = (now - self.last_replan_time).nanoseconds / 1e9
            if dt < self.replan_min_interval:
                return

        self.last_replan_time = now
        self.get_logger().info(f'Requesting replan: {reason}')

        # Stop current motion while we wait for a new path
        self.current_path_world = None
        self.current_path_index = 0
        self.last_v = 0.0
        self.last_omega = 0.0
        self.last_cmd_time = None
        self.cmd_vel_pub.publish(Twist())

        self.goal_pub.publish(self.current_goal_msg)

    def is_world_point_blocked_local(self, x, y):
        if self.obstacle_costmap_info is None or self.obstacle_costmap is None:
            return False

        cell = self.obstacle_world_to_grid(x, y)
        if cell is None:
            return False

        c = self.obstacle_cost_at(*cell)
        if c is None:
            return False

        return c >= self.obstacle_lethal_cost or c < 0

    def future_path_blocked(self, rx, ry):
        if not self.current_path_world:
            return False
        if self.obstacle_costmap_info is None or self.obstacle_costmap is None:
            return False

        lookahead = self.obstacle_replan_lookahead_distance
        cum_dist = 0.0
        prev_x, prev_y = rx, ry

        for i in range(self.current_path_index, len(self.current_path_world)):
            wx, wy = self.current_path_world[i]
            seg = math.hypot(wx - prev_x, wy - prev_y)
            cum_dist += seg

            if cum_dist > lookahead:
                break

            if self.is_world_point_blocked_local(wx, wy):
                self.get_logger().info(
                    f'Future path blocked near waypoint {i} at ({wx:.2f}, {wy:.2f})'
                )
                return True

            prev_x, prev_y = wx, wy

        return False


    # ---------- Control loop ----------

    def control_loop(self):
        if not self.current_path_world:
            return

        pose = self.get_robot_pose_map()
        if pose is None:
            return

        rx, ry, ryaw = pose
        n = len(self.current_path_world)

        goal_x, goal_y = self.current_path_world[-1]
        dist_to_goal = math.hypot(goal_x - rx, goal_y - ry)

        # Proactive replan
        if self.future_path_blocked(rx, ry):
            self.request_replan('future path blocked in local costmap')
            return

        # ---- Goal region + final orientation ----
        if dist_to_goal < self.goal_tolerance:
            if self.goal_yaw is not None:
                yaw_error_goal = self.normalize_angle(self.goal_yaw - ryaw)
                if abs(yaw_error_goal) > self.yaw_tolerance:
                    omega = self.angular_gain * yaw_error_goal
                    omega = max(-self.max_angular_speed,
                                min(self.max_angular_speed, omega))
                    twist = Twist()
                    twist.linear.x = 0.0
                    twist.angular.z = omega

                    if self.travel_start_time is None and abs(omega) > 1e-3:
                        self.travel_start_time = self.get_clock().now()

                    self.cmd_vel_pub.publish(twist)
                    return

            # fully done
            self.get_logger().info('Goal position and orientation reached, stopping.')
            if self.travel_start_time is not None:
                now = self.get_clock().now()
                travel_time = (now - self.travel_start_time).nanoseconds / 1e9
                self.get_logger().info(
                    f'Travel time from first motion command to goal stop: {travel_time:.3f} s'
                )
                self.travel_start_time = None

            self.current_path_world = None
            self.current_path_index = 0
            self.goal_yaw = None
            self.last_v = 0.0
            self.last_omega = 0.0
            self.last_cmd_time = None
            self.cmd_vel_pub.publish(Twist())
            return

        # ---- Progress along path ----
        waypoint_tolerance = self.lookahead_distance * 0.5
        while self.current_path_index < n:
            wx, wy = self.current_path_world[self.current_path_index]
            if math.hypot(wx - rx, wy - ry) < waypoint_tolerance:
                self.current_path_index += 1
            else:
                break
        if self.current_path_index >= n:
            self.current_path_index = n - 1

        # ---- Choose lookahead target ----
        lookahead = self.lookahead_distance
        target_x, target_y = self.current_path_world[self.current_path_index]

        for i in range(self.current_path_index, n):
            wx, wy = self.current_path_world[i]
            if math.hypot(wx - rx, wy - ry) >= lookahead:
                target_x, target_y = wx, wy
                self.current_path_index = i
                break

        dx = target_x - rx
        dy = target_y - ry
        desired_yaw = math.atan2(dy, dx)
        yaw_error = self.normalize_angle(desired_yaw - ryaw)

        # ---- Optional reversing ----
        # If the target is mostly behind us, it can be better to reverse instead of turning ~180°.
        # rear_angle = angle from current heading to target direction (same as yaw_error)
        reverse = False
        reverse_angle_threshold = 2.2  # rad (~126°). Tune: 1.8–2.6
        if abs(yaw_error) > reverse_angle_threshold:
            reverse = True
            # If driving backwards, the "desired" facing is flipped by pi
            yaw_error = self.normalize_angle(yaw_error + math.pi)


        # ---- Desired angular velocity ----
        desired_omega = self.angular_gain * yaw_error
        desired_omega = max(-self.max_angular_speed,
                            min(self.max_angular_speed, desired_omega))

        # ---- Desired linear velocity ----
        orientation_slowdown_distance = 0.8
        if dist_to_goal > orientation_slowdown_distance:
            heading_factor = 1.0
        else:
            heading_factor = max(0.0, math.cos(yaw_error))

        desired_v_mag = self.linear_gain * dist_to_goal * heading_factor
        desired_v_mag = max(0.0, min(self.max_linear_speed, desired_v_mag))

        # Minimum speed when far enough from goal
        if dist_to_goal > 1.0 and desired_v_mag > 0.0 and desired_v_mag < self.min_linear_speed:
            desired_v_mag = self.min_linear_speed

        # Apply direction
        desired_v = -desired_v_mag if reverse else desired_v_mag


        # ---- Obstacle-based slowdown using local costmap ----
        obstacle_factor = self.compute_obstacle_slowdown_factor(rx, ry)
        desired_v *= obstacle_factor

        # ---- Acceleration limiting ----
        now = self.get_clock().now()
        if self.last_cmd_time is None:
            dt = 0.1  # fallback
        else:
            dt = (now - self.last_cmd_time).nanoseconds / 1e9
            if dt <= 0.0:
                dt = 0.1
        self.last_cmd_time = now

        max_dv = self.max_linear_accel * dt
        max_domega = self.max_angular_accel * dt

        v = max(self.last_v - max_dv, min(self.last_v + max_dv, desired_v))
        omega = max(self.last_omega - max_domega, min(self.last_omega + max_domega, desired_omega))

        self.last_v = v
        self.last_omega = omega

        # ---- Publish cmd_vel ----
        twist = Twist()
        twist.linear.x = float(v)
        twist.angular.z = float(omega)

        if self.travel_start_time is None and (abs(v) > 1e-3 or abs(omega) > 1e-3):
            self.travel_start_time = self.get_clock().now()

        self.cmd_vel_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = SimpleController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()


