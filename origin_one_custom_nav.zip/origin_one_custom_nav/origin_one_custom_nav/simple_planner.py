#!/usr/bin/env python3

import math
import heapq  # for A* priority queue

import rclpy
from rclpy.node import Node
from rclpy.time import Time

from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import OccupancyGrid
import tf2_ros
from tf2_ros import TransformException

def yaw_from_quaternion(q):
    """Compute yaw (rotation around Z) from a geometry_msgs Quaternion."""
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


class SimplePlanner(Node):
    """
    Custom global+local planner:

      - subscribes to /goal_point (PoseStamped in 'map' frame)
      - gets robot pose (map -> base_link) via TF
      - subscribes to a global costmap (OccupancyGrid)
      - runs A* on the grid from start_cell to goal_cell
      - follows the resulting path by publishing cmd_vel to /cmd_vel_relay
    """

    def __init__(self):
        super().__init__('simple_planner')

        # TF buffer + listener: this lets us query transforms like map -> base_link
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # Parameter so you can change the topic if needed:
        #   ros2 run ... --ros-args -p costmap_topic:=/your_costmap_topic
        self.declare_parameter('costmap_topic', '/global_costmap/costmap')
        self.costmap_topic = (
            self.get_parameter('costmap_topic')
            .get_parameter_value()
            .string_value
        )

        self.costmap = None        # 1D list of int8, size = width * height
        self.costmap_info = None   # nav_msgs/msg/MapMetaData
        self.costmap_received = False

        # A* settings
        # Cells with cost >= lethal_cost or cost < 0 (unknown) will be treated as obstacles
        self.lethal_cost = 100
        self.allow_unknown = False  # if True, unknown (-1) is allowed; for now we block it

        self.costmap_sub = self.create_subscription(
            OccupancyGrid,
            self.costmap_topic,
            self.costmap_callback,
            10
        )

        # Subscribe to goals given as coordinates (PoseStamped in map frame)
        self.goal_sub = self.create_subscription(
            PoseStamped,
            '/goal_point',
            self.goal_callback,
            10
        )

        self.declare_parameter('cmd_vel_topic', '/cmd_vel')
        self.cmd_vel_topic = (
            self.get_parameter('cmd_vel_topic')
            .get_parameter_value()
            .string_value
        )
        self.cmd_vel_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)

        self.current_path_cells = None   # list of (mx, my)
        self.current_path_world = None   # list of (x, y)
        self.current_path_index = 0
        
        self.goal_yaw = None  		 # desired final orientation at goal (rad)
        
        self.travel_start_time = None

        self.declare_parameter('lookahead_distance', 0.6)   # m
        self.declare_parameter('goal_tolerance', 0.20)      # m
        self.declare_parameter('linear_gain', 0.7)
        self.declare_parameter('angular_gain', 1.2)
        self.declare_parameter('max_linear_speed', 0.25)    # m/s
        self.declare_parameter('max_angular_speed', 1.5)    # rad/s
        self.declare_parameter('robot_radius', 0.45)	    # m
        self.declare_parameter('safety_margin', 0.05)       # m
        self.declare_parameter('yaw_tolerance', 0.1)        # ~6 degrees

        self.lookahead_distance = self.get_parameter('lookahead_distance').value
        self.goal_tolerance = self.get_parameter('goal_tolerance').value
        self.linear_gain = self.get_parameter('linear_gain').value
        self.angular_gain = self.get_parameter('angular_gain').value
        self.max_linear_speed = self.get_parameter('max_linear_speed').value
        self.max_angular_speed = self.get_parameter('max_angular_speed').value
        self.robot_radius = self.get_parameter('robot_radius').value
        self.safety_margin = self.get_parameter('safety_margin').value
        self.yaw_tolerance = self.get_parameter('yaw_tolerance').value

        # Control loop timer (10 Hz)
        self.control_timer = self.create_timer(0.1, self.control_loop)

        self.get_logger().info(
            f'SimplePlanner node started. Waiting for /goal_point, costmap on '
            f'"{self.costmap_topic}", publishing cmd_vel on "{self.cmd_vel_topic}" ...'
        )

    def costmap_callback(self, msg: OccupancyGrid):
        """Store the latest costmap and its meta-info."""
        self.costmap = list(msg.data)
        self.costmap_info = msg.info

        if not self.costmap_received:
            self.costmap_received = True
            w = msg.info.width
            h = msg.info.height
            res = msg.info.resolution
            ox = msg.info.origin.position.x
            oy = msg.info.origin.position.y

            self.get_logger().info(
                f'Costmap received on "{self.costmap_topic}": '
                f'{w}x{h} cells, res={res:.3f} m, origin=({ox:.3f}, {oy:.3f})'
            )

    def world_to_grid(self, x, y):
        """
        Convert world coordinates (x, y) in the costmap frame into
        integer grid indices (mx, my). Returns None if outside the map.
        """
        if self.costmap_info is None:
            return None

        res = self.costmap_info.resolution
        w = self.costmap_info.width
        h = self.costmap_info.height
        origin = self.costmap_info.origin.position

        mx = int((x - origin.x) / res)
        my = int((y - origin.y) / res)

        if 0 <= mx < w and 0 <= my < h:
            return mx, my
        else:
            return None

    def grid_to_world(self, mx, my):
        """
        Convert grid indices (mx, my) into world coordinates (x, y)
        at the center of the cell.
        """
        if self.costmap_info is None:
            return None

        res = self.costmap_info.resolution
        origin = self.costmap_info.origin.position

        x = origin.x + (mx + 0.5) * res
        y = origin.y + (my + 0.5) * res
        return x, y

    def cost_at(self, mx, my):
        """
        Return occupancy value at cell (mx, my).
        In OccupancyGrid: -1 unknown, 0 free, 100 occupied (usually).
        """
        if self.costmap is None or self.costmap_info is None:
            return None

        w = self.costmap_info.width
        h = self.costmap_info.height

        if not (0 <= mx < w and 0 <= my < h):
            return None

        idx = my * w + mx   # row-major indexing
        return self.costmap[idx]

    def is_cell_safe_for_robot(self, mx, my):
        """
        Check whether placing the robot's center in cell (mx, my) would keep
        its circular footprint (radius = robot_radius + safety_margin)
        free of lethal/unknown cells.
        """
        if self.costmap_info is None:
            return False

        res = self.costmap_info.resolution
        w = self.costmap_info.width
        h = self.costmap_info.height

        # radius in cells (ceil to be conservative)
        radius_m = self.robot_radius + self.safety_margin
        radius_cells = int(math.ceil(radius_m / res))

        for dx in range(-radius_cells, radius_cells + 1):
            for dy in range(-radius_cells, radius_cells + 1):
                nx = mx + dx
                ny = my + dy

                # outside map = treat as obstacle
                if not (0 <= nx < w and 0 <= ny < h):
                    return False

                # Only check cells inside the circle (optional but nicer)
                if dx*dx + dy*dy > radius_cells * radius_cells:
                    continue

                c = self.cost_at(nx, ny)
                if c is None:
                    return False
                if c < 0 and not self.allow_unknown:
                    return False
                if c >= self.lethal_cost:
                    return False

        return True


    def is_cell_walkable(self, mx, my):
        """
        Decide if a cell can be traversed by the planner, taking into account
        the robot's footprint (not just a point).
        """
        c = self.cost_at(mx, my)
        if c is None:
            return False

        if c < 0 and not self.allow_unknown:
            # unknown cell
            return False

        if c >= self.lethal_cost:
            # occupied or very high cost
            return False

        return self.is_cell_safe_for_robot(mx, my)

    def get_robot_pose_map(self):
        """
        Returns (x, y, yaw) of base_link in map frame, or None if transform not available.
        """
        try:
            # Time() with no arguments = "latest available" transform
            transform = self.tf_buffer.lookup_transform(
                'map',          # target frame
                'base_link',    # source frame
                Time()
            )
        except TransformException as ex:
            self.get_logger().warn(f'Could not transform map -> base_link: {ex}')
            return None

        t = transform.transform.translation
        r = transform.transform.rotation

        x = t.x
        y = t.y
        yaw = yaw_from_quaternion(r)

        return x, y, yaw

    def neighbors(self, cell):
        """
        Generate neighbor cells and their move costs.
        8-connected grid: N, S, E, W, and diagonals.
        """
        (mx, my) = cell
        # (dx, dy, movement_cost)
        steps = [
            (1, 0, 1.0),
            (-1, 0, 1.0),
            (0, 1, 1.0),
            (0, -1, 1.0),
            (1, 1, math.sqrt(2.0)),
            (-1, 1, math.sqrt(2.0)),
            (1, -1, math.sqrt(2.0)),
            (-1, -1, math.sqrt(2.0)),
        ]

        w = self.costmap_info.width
        h = self.costmap_info.height

        for dx, dy, cost in steps:
            nx = mx + dx
            ny = my + dy
            if 0 <= nx < w and 0 <= ny < h:
                if self.is_cell_walkable(nx, ny):
                    yield (nx, ny), cost

    def heuristic(self, cell, goal):
        """
        Heuristic for A*: use Euclidean distance between cells.
        """
        (mx, my) = cell
        (gx, gy) = goal
        return math.hypot(gx - mx, gy - my)

    def reconstruct_path(self, came_from, current):
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        path.reverse()
        return path

    def a_star(self, start, goal):
        """
        Run A* on the current costmap grid from start cell to goal cell.

        start, goal: (mx, my)
        Returns: list of cells [(mx, my), ...] if path found, else None.
        """
        if self.costmap_info is None or self.costmap is None:
            self.get_logger().warn('Cannot run A*: no costmap available.')
            return None

        if not self.is_cell_walkable(*start):
            self.get_logger().warn(f'Start cell {start} is not walkable.')
            return None

        if not self.is_cell_walkable(*goal):
            self.get_logger().warn(f'Goal cell {goal} is not walkable.')
            return None

        open_set = []
        heapq.heappush(open_set, (0.0, start))

        came_from = {}
        g_score = {start: 0.0}

        visited = 0

        while open_set:
            _, current = heapq.heappop(open_set)
            visited += 1

            if current == goal:
                path = self.reconstruct_path(came_from, current)
                self.get_logger().info(
                    f'A* found a path with {len(path)} cells '
                    f'after expanding {visited} nodes.'
                )
                return path, visited

            for neighbor, move_cost in self.neighbors(current):
                tentative_g = g_score[current] + move_cost

                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score = tentative_g + self.heuristic(neighbor, goal)
                    heapq.heappush(open_set, (f_score, neighbor))

        self.get_logger().warn(
            f'A* could not find a path from {start} to {goal} '
            f'(expanded {visited} nodes).'
        )
        return None, visited

    @staticmethod
    def normalize_angle(angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def control_loop(self):
        """
        Run at fixed rate. If we have a path, follow it and publish cmd_vel.
        """
        # No path? stop and do nothing
        if not self.current_path_world:
            # You might want to actively stop:
            # self.cmd_vel_pub.publish(Twist())
            return

        pose = self.get_robot_pose_map()
        if pose is None:
            return

        rx, ry, ryaw = pose

        # Final goal is last waypoint
        goal_x, goal_y = self.current_path_world[-1]
        dist_to_goal = math.hypot(goal_x - rx, goal_y - ry)

        if dist_to_goal < self.goal_tolerance:
            # We are close enough in position: now enforce final orientation if requested
            if self.goal_yaw is not None:
                yaw_error_goal = self.normalize_angle(self.goal_yaw - ryaw)

                if abs(yaw_error_goal) > self.yaw_tolerance:
                    # Rotate in place towards the final desired yaw
                    omega = self.angular_gain * yaw_error_goal
                    omega = max(-self.max_angular_speed, min(self.max_angular_speed, omega))

                    twist = Twist()
                    twist.linear.x = 0.0
                    twist.angular.z = omega
                    self.cmd_vel_pub.publish(twist)
                    return

            # Position is good AND orientation is good (or no orientation requested): stop
            self.get_logger().info('Goal position and orientation reached, stopping.')
            
            # Compute travel time if we have a start time
            if self.travel_start_time is not None:
                now = self.get_clock().now()
                travel_time = (now - self.travel_start_time).nanoseconds / 1e9
                self.get_logger().info(
                    f'Travel time from first motion command to goal stop: {travel_time:.3f} s'
                )
                self.travel_start_time = None
            
            self.current_path_world = None
            self.current_path_cells = None
            self.current_path_index = 0
            self.goal_yaw = None
            self.cmd_vel_pub.publish(Twist())
            return
            
        # If we're very close to the current waypoint, move to the next
        waypoint_tolerance = self.lookahead_distance * 0.5
        n = len(self.current_path_world)

        while self.current_path_index < n:
            wx, wy = self.current_path_world[self.current_path_index]
            if math.hypot(wx - rx, wy - ry) < waypoint_tolerance:
                self.current_path_index += 1
            else:
                break

        # Clamp index to last waypoint if we overshoot
        if self.current_path_index >= n:
            self.current_path_index = n - 1

        # Pick lookahead target along the path
        lookahead = self.lookahead_distance
        target_x, target_y = self.current_path_world[-1]  # default: last
        
        for i in range(self.current_path_index, n):
            wx, wy = self.current_path_world[i]
            if math.hypot(wx - rx, wy - ry) >= lookahead:
                target_x, target_y = wx, wy
                self.current_path_index = i  # we know we've reached at least this far
                break

        # Compute control
        dx = target_x - rx
        dy = target_y - ry
        desired_yaw = math.atan2(dy, dx)
        yaw_error = self.normalize_angle(desired_yaw - ryaw)

        # Angular velocity
        omega = self.angular_gain * yaw_error
        omega = max(-self.max_angular_speed, min(self.max_angular_speed, omega))

        # Distance at which we start caring about orientation for speed [m]
        orientation_slowdown_distance = 0.8  # tweak if you like

        if dist_to_goal > orientation_slowdown_distance:
            # Far from goal: just drive, ignore yaw for speed
            heading_factor = 1.0
        else:
            # Close to goal: slow down if we're not aligned
            heading_factor = max(0.0, math.cos(yaw_error))

        v = self.linear_gain * dist_to_goal * heading_factor
        v = max(0.0, min(self.max_linear_speed, v))

        twist = Twist()
        twist.linear.x = v
        twist.angular.z = omega
        
        # Start travel timer when we first send a non-zero command
        if self.travel_start_time is None and (abs(v) > 1e-3 or abs(omega) > 1e-3):
            self.travel_start_time = self.get_clock().now()
        
        self.cmd_vel_pub.publish(twist)

    def goal_callback(self, msg: PoseStamped):
        # Basic sanity check: frame_id
        frame = msg.header.frame_id
        gx = msg.pose.position.x
        gy = msg.pose.position.y
        goal_q = msg.pose.orientation
        self.goal_yaw = yaw_from_quaternion(goal_q)

        self.current_path_cells = None
        self.current_path_world = None
        self.current_path_index = 0
        self.travel_start_time = None

        # Look up robot pose in map frame
        pose = self.get_robot_pose_map()
        if pose is None:
            self.get_logger().warn(
                f'Received goal in frame "{frame}" (x={gx:.3f}, y={gy:.3f}) '
                f'but robot pose is not available yet.'
            )
            return

        rx, ry, ryaw = pose

        if self.costmap_info is None:
            self.get_logger().warn(
                'Costmap not received yet, cannot plan.'
            )
            self.current_path_world = None
            self.current_path_cells = None
            self.current_path_index = 0
            self.goal_yaw = None
            self.travel_start_time = None
            self.cmd_vel_pub.publish(Twist())
            return

        # Convert to grid coordinates
        start_cell = self.world_to_grid(rx, ry)
        goal_cell = self.world_to_grid(gx, gy)

        if start_cell is None or goal_cell is None:
            self.get_logger().warn(
                f'Either start {start_cell} or goal {goal_cell} is outside the costmap.'
            )
            return

        self.get_logger().info(
            f'Planning from start cell {start_cell} to goal cell {goal_cell} ...'
        )

        # Run A*
        start_time = self.get_clock().now()
        
        path_cells, visited = self.a_star(start_cell, goal_cell)

        end_time = self.get_clock().now()
        planning_duration = (end_time - start_time).nanoseconds / 1e9

        if path_cells is None:
            self.current_path_cells = None
            self.current_path_world = None
            self.current_path_index = 0
            self.goal_yaw = None
            self.travel_start_time = None
            self.cmd_vel_pub.publish(Twist())
            self.get_logger().info(
                f'Planning failed after expanding {visited} nodes '
                f'in {planning_duration:.3f} s.'
            )
            return

        # Convert path to world coordinates
        path_world = []
        for (mx, my) in path_cells:
            p = self.grid_to_world(mx, my)
            if p is not None:
                path_world.append(p)

        self.current_path_cells = path_cells
        self.current_path_world = path_world
        self.current_path_index = 0

        path_length = 0.0
        for i in range(1, len(path_world)):
            x0, y0 = path_world[i - 1]
            x1, y1 = path_world[i]
            path_length += math.hypot(x1 - x0, y1 - y0)

        # ---- Log metrics ----
        self.get_logger().info(
            f'Path has {len(path_world)} waypoints, '
            f'length={path_length:.2f} m, '
            f'planning_time={planning_duration:.3f} s, '
            f'expanded_nodes={visited}.'
        )
        
        if len(path_world) > 0:
            preview = ', '.join(
                f'({x:.2f}, {y:.2f})' for (x, y) in path_world[:5]
            )
            self.get_logger().info(f'First waypoints: {preview}{" ..." if len(path_world) > 5 else ""}')

        # (Next step: use this path_world to generate cmd_vel commands)

        self.get_logger().info(
            f'Received goal in frame "{frame}": '
            f'goal=({gx:.3f}, {gy:.3f}), '
            f'robot=({rx:.3f}, {ry:.3f}, yaw={ryaw:.3f} rad)'
        )


def main(args=None):
    rclpy.init(args=args)
    node = SimplePlanner()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

