#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from rclpy.time import Time

from geometry_msgs.msg import Twist, PoseStamped
from nav_msgs.msg import Path, OccupancyGrid
import tf2_ros
from tf2_ros import TransformException


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


class SimpleController(Node):
    """
    Path-following controller:
      - subscribes to nav_msgs/Path on /custom_plan
      - uses TF to get robot pose in 'map'
      - follows the path with a lookahead controller
      - enforces final orientation at goal
      - publishes cmd_vel on /cmd_vel
      - can request replans if local obstacles block the path
    """

    def __init__(self):
        super().__init__('simple_controller')

        # Parameters
        self.declare_parameter('plan_topic', '/custom_plan')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')

        self.declare_parameter('lookahead_distance', 0.6)
        self.declare_parameter('goal_tolerance', 0.20)
        self.declare_parameter('yaw_tolerance', 0.10)
        self.declare_parameter('linear_gain', 0.7)
        self.declare_parameter('angular_gain', 1.2)
        self.declare_parameter('min_linear_speed', 0.08)      # m/s when far from goal
        self.declare_parameter('max_linear_speed', 0.25)
        self.declare_parameter('max_angular_speed', 1.0)
        self.declare_parameter('max_linear_accel', 0.3)       # m/s^2
        self.declare_parameter('max_angular_accel', 1.5)      # rad/s^2
        self.declare_parameter('allow_reversing', True)

        self.declare_parameter('obstacle_costmap_topic', '/local_costmap/costmap')
        self.declare_parameter('obstacle_check_radius', 0.7)  # m around robot
        self.declare_parameter('obstacle_lethal_cost', 200)   # cost value ~ "very bad"
        self.declare_parameter('obstacle_slowdown_gain', 0.7) # how strongly we slow down

        self.declare_parameter('goal_topic', '/goal_point')
        self.declare_parameter('replan_min_interval', 2.0)            # s, throttle
        self.declare_parameter('progress_distance_threshold', 0.05)   # m
        self.declare_parameter('obstacle_replan_lookahead_distance', 1.5)  # m
        
        self.declare_parameter('enable_midpath_spin', True)
        self.declare_parameter('spin_cost_threshold', 90)        # stricter than obstacle_lethal_cost
        self.declare_parameter('spin_check_radius', 0.65)        # meters around robot center
        self.declare_parameter('spin_waypoint_tolerance', 0.25)  # meters
        self.declare_parameter('spin_sample_step', 0.40)         # meters along path to test
        
        self.declare_parameter('final_rotate_check_radius', 0.6)
        self.declare_parameter('final_rotate_max_cost', 80)   # if max cost >= this, skip rotate
        
        self.declare_parameter('enable_holonomic', True)
        self.declare_parameter('lateral_gain', 0.7)
        self.declare_parameter('max_lateral_speed', 0.20)
        self.declare_parameter('max_lateral_accel', 0.3)
        self.declare_parameter('motion_mode', 'auto') # 'auto' | 'holonomic' | 'nonholonomic'
        self.declare_parameter('holonomic_distance_threshold', 1.2)  # m
        self.declare_parameter('holonomic_lateral_error_threshold', 0.25)  # m

        self.plan_topic = self.get_parameter('plan_topic').value
        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.lookahead_distance = float(self.get_parameter('lookahead_distance').value)
        self.goal_tolerance = float(self.get_parameter('goal_tolerance').value)
        self.yaw_tolerance = float(self.get_parameter('yaw_tolerance').value)
        self.linear_gain = float(self.get_parameter('linear_gain').value)
        self.angular_gain = float(self.get_parameter('angular_gain').value)
        self.min_linear_speed = float(self.get_parameter('min_linear_speed').value)
        self.max_linear_speed = float(self.get_parameter('max_linear_speed').value)
        self.max_angular_speed = float(self.get_parameter('max_angular_speed').value)
        self.max_linear_accel = float(self.get_parameter('max_linear_accel').value)
        self.max_angular_accel = float(self.get_parameter('max_angular_accel').value)
        self.allow_reversing = bool(self.get_parameter('allow_reversing').value)

        self.obstacle_costmap_topic = self.get_parameter('obstacle_costmap_topic').value
        self.obstacle_check_radius = float(self.get_parameter('obstacle_check_radius').value)
        self.obstacle_lethal_cost = float(self.get_parameter('obstacle_lethal_cost').value)
        self.obstacle_slowdown_gain = float(self.get_parameter('obstacle_slowdown_gain').value)

        self.goal_topic = self.get_parameter('goal_topic').value
        self.replan_min_interval = float(self.get_parameter('replan_min_interval').value)
        self.progress_distance_threshold = float(self.get_parameter('progress_distance_threshold').value)
        self.obstacle_replan_lookahead_distance = float(
            self.get_parameter('obstacle_replan_lookahead_distance').value
        )
        
        self.enable_midpath_spin = bool(self.get_parameter('enable_midpath_spin').value)
        self.spin_cost_threshold = float(self.get_parameter('spin_cost_threshold').value)
        self.spin_check_radius = float(self.get_parameter('spin_check_radius').value)
        self.spin_waypoint_tolerance = float(self.get_parameter('spin_waypoint_tolerance').value)
        self.spin_sample_step = float(self.get_parameter('spin_sample_step').value)
        
        self.final_rotate_check_radius = float(self.get_parameter('final_rotate_check_radius').value)
        self.final_rotate_max_cost = float(self.get_parameter('final_rotate_max_cost').value)
        
        self.enable_holonomic = bool(self.get_parameter('enable_holonomic').value)
        self.lateral_gain = float(self.get_parameter('lateral_gain').value)
        self.max_lateral_speed = float(self.get_parameter('max_lateral_speed').value)
        self.max_lateral_accel = float(self.get_parameter('max_lateral_accel').value)
        self.motion_mode = self.get_parameter('motion_mode').value
        self.holonomic_distance_threshold = float(
            self.get_parameter('holonomic_distance_threshold').value
        )
        self.holonomic_lateral_error_threshold = float(
            self.get_parameter('holonomic_lateral_error_threshold').value
        )


        # TF
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # State
        self.current_path_world = None  # list of (x, y)
        self.current_path_index = 0
        self.goal_yaw = None
        self.travel_start_time = None
        self.last_cmd_time = None
        self.last_v = 0.0
        self.last_omega = 0.0
        self.obstacle_costmap = None
        self.obstacle_costmap_info = None
        self.current_goal_msg = None
        self.last_replan_time = None
        self.last_progress_pose = None
        
        self.user_desired_yaw = None
        self.yaw_at_goal_receive = None

        self.spin_requested = False
        self.spin_done = False
        self.spin_abandoned = False

        self.spin_target_index = None  # index in current_path_world where we should spin
        self.spin_target_xy = None     # (x, y)
        
        self.last_vy = 0.0


        # Sub / Pub
        self.plan_sub = self.create_subscription(
            Path, self.plan_topic, self.plan_callback, 10
        )
        self.cmd_vel_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)

        self.obstacle_costmap_sub = self.create_subscription(
            OccupancyGrid,
            self.obstacle_costmap_topic,
            self.obstacle_costmap_callback,
            10
        )

        self.goal_sub = self.create_subscription(
            PoseStamped,
            self.goal_topic,
            self.goal_callback,
            10
        )
        self.goal_pub = self.create_publisher(PoseStamped, self.goal_topic, 10)

        # Control loop timer (10 Hz)
        self.control_timer = self.create_timer(0.1, self.control_loop)

        self.get_logger().info(
            f'SimpleController started. '
            f'Listening for Path on "{self.plan_topic}", '
            f'publishing cmd_vel on "{self.cmd_vel_topic}".'
        )

    # ---------- TF helper ----------

    def get_robot_pose_map(self):
        try:
            transform = self.tf_buffer.lookup_transform(
                'map', 'base_link', Time()
            )
        except TransformException as ex:
            self.get_logger().warn(f'Could not transform map -> base_link: {ex}')
            return None
        t = transform.transform.translation
        r = transform.transform.rotation
        x = t.x
        y = t.y
        yaw = yaw_from_quaternion(r)
        return x, y, yaw

    @staticmethod
    def normalize_angle(angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    # ---------- Plan callback ----------

    def plan_callback(self, msg: Path):
        if not msg.poses:
            self.get_logger().warn('Received empty path, stopping.')
            self.current_path_world = None
            self.current_path_index = 0
            self.goal_yaw = None
            self.travel_start_time = None
            self.last_v = 0.0
            self.last_omega = 0.0
            self.last_cmd_time = None
            self.last_vy = 0.0
            self.cmd_vel_pub.publish(Twist())
            return

        path_world = []
        for pose_stamped in msg.poses:
            x = pose_stamped.pose.position.x
            y = pose_stamped.pose.position.y
            path_world.append((x, y))

        last_pose = msg.poses[-1].pose
        self.goal_yaw = yaw_from_quaternion(last_pose.orientation)

        self.current_path_world = path_world
        self.current_path_index = 0
        self.travel_start_time = None  # reset timer for new path
        
        # Decide where we could do the mid-path spin (if requested)
        if self.spin_requested and not self.spin_done and not self.spin_abandoned:
            self.select_spin_waypoint()

            # If no spin spot exists, abandon user yaw and keep initial yaw
            if self.spin_target_index is None:
                self.spin_abandoned = True
                if self.yaw_at_goal_receive is not None:
                    self.goal_yaw = self.yaw_at_goal_receive
                # else: fall back to whatever the path's goal_yaw was
        

        self.get_logger().info(
            f'Received new path with {len(path_world)} waypoints.'
        )

    def world_error_in_robot_frame(self, rx, ry, ryaw, tx, ty):
        """
        Returns (ex_r, ey_r): target position error expressed in robot frame.
        +x = forward, +y = left (ROS base_link convention).
        """
        dx = tx - rx
        dy = ty - ry

        cy = math.cos(ryaw)
        sy = math.sin(ryaw)

        # rotate world error into robot frame: R(-yaw)*[dx,dy]
        ex_r =  cy * dx + sy * dy
        ey_r = -sy * dx + cy * dy
        return ex_r, ey_r


    # ---------- Obstacle costmap helpers ----------

    def obstacle_costmap_callback(self, msg: OccupancyGrid):
        self.obstacle_costmap = list(msg.data)
        self.obstacle_costmap_info = msg.info

    def obstacle_world_to_grid(self, x, y):
        if self.obstacle_costmap_info is None:
            return None
        info = self.obstacle_costmap_info
        res = info.resolution
        origin = info.origin.position
        mx = int((x - origin.x) / res)
        my = int((y - origin.y) / res)
        if 0 <= mx < info.width and 0 <= my < info.height:
            return mx, my
        return None

    def obstacle_cost_at(self, mx, my):
        if self.obstacle_costmap is None or self.obstacle_costmap_info is None:
            return None
        info = self.obstacle_costmap_info
        if not (0 <= mx < info.width and 0 <= my < info.height):
            return None
        idx = my * info.width + mx
        return self.obstacle_costmap[idx]

    def compute_obstacle_slowdown_factor(self, rx, ry):
        if self.obstacle_costmap_info is None or self.obstacle_costmap is None:
            return 1.0

        cell = self.obstacle_world_to_grid(rx, ry)
        if cell is None:
            return 1.0

        mx_center, my_center = cell
        info = self.obstacle_costmap_info
        res = info.resolution

        radius_cells = int(math.ceil(self.obstacle_check_radius / res))
        max_cost = 0.0

        for dx in range(-radius_cells, radius_cells + 1):
            for dy in range(-radius_cells, radius_cells + 1):
                nx = mx_center + dx
                ny = my_center + dy
                if not (0 <= nx < info.width and 0 <= ny < info.height):
                    continue
                if dx * dx + dy * dy > radius_cells * radius_cells:
                    continue

                c = self.obstacle_cost_at(nx, ny)
                if c is None or c < 0:
                    continue
                if c > max_cost:
                    max_cost = c

        if max_cost <= 0.0:
            return 1.0

        cost_ratio = min(max_cost / self.obstacle_lethal_cost, 1.0)
        slowdown = cost_ratio * self.obstacle_slowdown_gain
        factor = max(0.0, 1.0 - slowdown)
        return factor

    def max_local_cost_in_radius(self, x, y, radius_m):
        """
        Returns the maximum local costmap value within radius_m of (x,y).
        If costmap not available, return 0 (treat as free).
        """
        if self.obstacle_costmap_info is None or self.obstacle_costmap is None:
            return 0

        cell = self.obstacle_world_to_grid(x, y)
        if cell is None:
            return 0

        mx_center, my_center = cell
        info = self.obstacle_costmap_info
        res = info.resolution
        radius_cells = int(math.ceil(radius_m / res))

        max_cost = 0
        for dx in range(-radius_cells, radius_cells + 1):
            for dy in range(-radius_cells, radius_cells + 1):
                nx = mx_center + dx
                ny = my_center + dy
                if not (0 <= nx < info.width and 0 <= ny < info.height):
                    continue
                if dx * dx + dy * dy > radius_cells * radius_cells:
                    continue
                c = self.obstacle_cost_at(nx, ny)
                if c is None:
                    continue
                if c < 0:
                    # unknown -> treat as risky near goal
                    return 999
                if c > max_cost:
                    max_cost = c
        return max_cost


    @staticmethod
    def dist(a, b):
        return math.hypot(a[0] - b[0], a[1] - b[1])

    def is_pose_spin_safe_local(self, x, y):
        """
        Conservative check: treat robot footprint as a disk and require that all costmap
        cells within spin_check_radius are below spin_cost_threshold.
        Uses LOCAL costmap (what matters for immediate clearance).
        """
        if self.obstacle_costmap_info is None or self.obstacle_costmap is None:
            return False

        cell = self.obstacle_world_to_grid(x, y)
        if cell is None:
            return False

        mx_center, my_center = cell
        info = self.obstacle_costmap_info
        res = info.resolution

        radius_cells = int(math.ceil(self.spin_check_radius / res))

        for dx in range(-radius_cells, radius_cells + 1):
            for dy in range(-radius_cells, radius_cells + 1):
                nx = mx_center + dx
                ny = my_center + dy
                if not (0 <= nx < info.width and 0 <= ny < info.height):
                    return False

                if dx * dx + dy * dy > radius_cells * radius_cells:
                    continue

                c = self.obstacle_cost_at(nx, ny)
                if c is None or c < 0:
                    return False

                if c >= self.spin_cost_threshold:
                    return False

        return True

    def select_spin_waypoint(self):
        """
        Choose the earliest waypoint along the path where an in-place spin is safe.
        Samples along the path every ~spin_sample_step meters.
        """
        self.spin_target_index = None
        self.spin_target_xy = None

        if not self.enable_midpath_spin:
            return

        if not self.current_path_world or len(self.current_path_world) < 3:
            return

        # Don’t spin too close to the goal: you already have final yaw enforcement there.
        avoid_tail = 3

        prev = self.current_path_world[0]
        acc = 0.0

        for i in range(1, max(1, len(self.current_path_world) - avoid_tail)):
            p = self.current_path_world[i]
            acc += self.dist(prev, p)
            prev = p

            if acc < self.spin_sample_step:
                continue
            acc = 0.0

            if self.is_pose_spin_safe_local(p[0], p[1]):
                self.spin_target_index = i
                self.spin_target_xy = p
                self.get_logger().info(
                    f'Found mid-path spin spot at index {i} (x={p[0]:.2f}, y={p[1]:.2f}) '
                    f'with spin_cost_threshold={self.spin_cost_threshold}.'
                )
                return

        # If we get here: none found
        self.get_logger().warn('No safe mid-path spin spot found along the path.')
      
        
    def fmt_pose(self, pose):
        if pose is None:
            return "x=?, y=?, yaw=?"
        x, y, yaw = pose
        return f"x={x:.3f}, y={y:.3f}, yaw={yaw:.3f} rad ({math.degrees(yaw):.1f} deg)"


    # ---------- Replanning helpers ----------

    def goal_callback(self, msg: PoseStamped):
        self.current_goal_msg = msg

        # NEW: remember user yaw + yaw at receive time
        self.user_desired_yaw = yaw_from_quaternion(msg.pose.orientation)

        pose = self.get_robot_pose_map()
        if pose is not None:
            _, _, ryaw = pose
            self.yaw_at_goal_receive = ryaw
        else:
            self.yaw_at_goal_receive = None

        # Reset spin state for this new goal
        self.spin_requested = True
        self.spin_done = False
        self.spin_abandoned = False
        self.spin_target_index = None
        self.spin_target_xy = None

    def request_replan(self, reason: str):
        if self.current_goal_msg is None:
            self.get_logger().warn('Cannot request replan: no remembered goal.')
            return

        now = self.get_clock().now()
        if self.last_replan_time is not None:
            dt = (now - self.last_replan_time).nanoseconds / 1e9
            if dt < self.replan_min_interval:
                return

        self.last_replan_time = now
        self.get_logger().info(f'Requesting replan: {reason}')

        # Stop current motion while we wait for a new path
        self.current_path_world = None
        self.current_path_index = 0
        self.last_v = 0.0
        self.last_omega = 0.0
        self.last_cmd_time = None
        self.last_vy = 0.0
        self.cmd_vel_pub.publish(Twist())

        self.goal_pub.publish(self.current_goal_msg)

    def is_world_point_blocked_local(self, x, y):
        if self.obstacle_costmap_info is None or self.obstacle_costmap is None:
            return False

        cell = self.obstacle_world_to_grid(x, y)
        if cell is None:
            return False

        c = self.obstacle_cost_at(*cell)
        if c is None:
            return False

        return c >= self.obstacle_lethal_cost or c < 0

    def future_path_blocked(self, rx, ry):
        if not self.current_path_world:
            return False
        if self.obstacle_costmap_info is None or self.obstacle_costmap is None:
            return False

        lookahead = self.obstacle_replan_lookahead_distance
        cum_dist = 0.0
        prev_x, prev_y = rx, ry

        for i in range(self.current_path_index, len(self.current_path_world)):
            wx, wy = self.current_path_world[i]
            seg = math.hypot(wx - prev_x, wy - prev_y)
            cum_dist += seg

            if cum_dist > lookahead:
                break

            if self.is_world_point_blocked_local(wx, wy):
                self.get_logger().info(
                    f'Future path blocked near waypoint {i} at ({wx:.2f}, {wy:.2f})'
                )
                return True

            prev_x, prev_y = wx, wy

        return False


    # ---------- Control loop ----------

    def control_loop(self):
        if not self.current_path_world:
            return

        pose = self.get_robot_pose_map()
        if pose is None:
            return

        rx, ry, ryaw = pose
        n = len(self.current_path_world)

        goal_x, goal_y = self.current_path_world[-1]
        dist_to_goal = math.hypot(goal_x - rx, goal_y - ry)

        # Proactive replan
        if self.future_path_blocked(rx, ry):
            self.request_replan('future path blocked in local costmap')
            return
            
        # NEW: Mid-path spin behavior
        if self.spin_requested and (not self.spin_done) and (not self.spin_abandoned):

            # If we never found a spin point, abandon desired yaw
            if self.spin_target_index is None or self.spin_target_xy is None:
                self.spin_abandoned = True
                if self.yaw_at_goal_receive is not None:
                    self.goal_yaw = self.yaw_at_goal_receive

            else:
                sx, sy = self.spin_target_xy
                dist_to_spin = math.hypot(sx - rx, sy - ry)

                # If we reached the spin location, stop and rotate to user yaw
                if dist_to_spin <= self.spin_waypoint_tolerance:
                    yaw_error_spin = self.normalize_angle(self.user_desired_yaw - ryaw)

                    if abs(yaw_error_spin) > self.yaw_tolerance:
                        omega = self.angular_gain * yaw_error_spin
                        omega = max(-self.max_angular_speed,
                                    min(self.max_angular_speed, omega))

                        twist = Twist()
                        twist.linear.x = 0.0
                        twist.angular.z = omega

                        # (optional) start timing if not started
                        if self.travel_start_time is None and abs(omega) > 1e-3:
                            self.travel_start_time = self.get_clock().now()

                        self.cmd_vel_pub.publish(twist)
                        return
                    else:
                        # Spin completed
                        self.spin_done = True
                        self.goal_yaw = self.user_desired_yaw
                        self.get_logger().info('Mid-path spin completed; continuing to goal.')
            

        # ---- Goal region + final orientation ----
        if dist_to_goal < self.goal_tolerance:
            if self.goal_yaw is not None:
                yaw_error_goal = self.normalize_angle(self.goal_yaw - ryaw)

                if abs(yaw_error_goal) > self.yaw_tolerance:
                    # Only rotate if the goal area is "spacious enough"
                    max_cost = self.max_local_cost_in_radius(
                        rx, ry, self.final_rotate_check_radius
                    )

                    if max_cost < self.final_rotate_max_cost:
                        omega = self.angular_gain * yaw_error_goal
                        # (Optional) slower final rotation reduces wall bumps
                        final_max_omega = min(self.max_angular_speed, 0.6)
                        omega = max(-final_max_omega, min(final_max_omega, omega))

                        twist = Twist()
                        twist.linear.x = 0.0
                        twist.angular.z = omega
                        
                        if self.travel_start_time is None and abs(omega) > 1e-3:
                            self.travel_start_time = self.get_clock().now()

                        self.cmd_vel_pub.publish(twist)
                        return
                    else:
                        self.get_logger().info(
                            f'Skipping final yaw alignment (too tight). max_local_cost={max_cost}'
                        )
                        
            
            self.get_logger().info('Goal position and orientation reached, stopping.')
            self.cmd_vel_pub.publish(Twist())
            
            final_pose = self.get_robot_pose_map()
            self.get_logger().info(f"Final pose at stop: {self.fmt_pose(final_pose)}")
            
            if self.travel_start_time is not None:
                now = self.get_clock().now()
                travel_time = (now - self.travel_start_time).nanoseconds / 1e9
                self.get_logger().info(
                    f'Travel time from first motion command to goal stop: {travel_time:.3f} s'
                )
                self.travel_start_time = None

            self.current_path_world = None
            self.current_path_index = 0
            self.goal_yaw = None
            self.last_v = 0.0
            self.last_omega = 0.0
            self.last_cmd_time = None
            self.spin_requested = False
            self.spin_done = False
            self.spin_abandoned = False
            self.spin_target_index = None
            self.spin_target_xy = None
            self.last_vy = 0.0

            return

        # ---- Progress along path ----
        waypoint_tolerance = self.lookahead_distance * 0.5
        while self.current_path_index < n:
            wx, wy = self.current_path_world[self.current_path_index]
            if math.hypot(wx - rx, wy - ry) < waypoint_tolerance:
                self.current_path_index += 1
            else:
                break
        if self.current_path_index >= n:
            self.current_path_index = n - 1

        # ---- Choose lookahead target ----
        lookahead = self.lookahead_distance
        target_x, target_y = self.current_path_world[self.current_path_index]

        for i in range(self.current_path_index, n):
            wx, wy = self.current_path_world[i]
            if math.hypot(wx - rx, wy - ry) >= lookahead:
                target_x, target_y = wx, wy
                self.current_path_index = i
                break

        # ----- Compute error to target in ROBOT frame -----
        ex_r, ey_r = self.world_error_in_robot_frame(rx, ry, ryaw, target_x, target_y)

        # ----- Select motion mode -----
        if self.motion_mode == 'holonomic':
            use_holonomic = self.enable_holonomic
        elif self.motion_mode == 'nonholonomic':
            use_holonomic = False
        else:
            # AUTO mode
            use_holonomic = (
                dist_to_goal < self.holonomic_distance_threshold
                or abs(ey_r) > self.holonomic_lateral_error_threshold
            )

            # Respect enable_holonomic flag
            if not self.enable_holonomic:
                use_holonomic = False

            # Optional: avoid holonomic when we are near high-cost cells (tight corridors)
            near_wall = self.max_local_cost_in_radius(rx, ry, 0.6) >= self.final_rotate_max_cost
            if near_wall:
                use_holonomic = False

        if use_holonomic:
            # ---------------- HOLONOMIC ----------------
            desired_vx = self.linear_gain * ex_r
            desired_vy = self.lateral_gain * ey_r

            desired_vx = max(-self.max_linear_speed, min(self.max_linear_speed, desired_vx))
            desired_vy = max(-self.max_lateral_speed, min(self.max_lateral_speed, desired_vy))

            # Mild minimum speed far away (optional)
            if dist_to_goal > 1.0 and abs(desired_vx) < self.min_linear_speed:
                if abs(ex_r) > abs(ey_r):
                    desired_vx = math.copysign(self.min_linear_speed, desired_vx if desired_vx != 0.0 else ex_r)

            # Heading control (keep it gentle)
            desired_yaw = math.atan2(target_y - ry, target_x - rx)
            yaw_error = self.normalize_angle(desired_yaw - ryaw)

            desired_omega = self.angular_gain * yaw_error
            desired_omega = max(-self.max_angular_speed, min(self.max_angular_speed, desired_omega))

            # Obstacle slowdown
            obstacle_factor = self.compute_obstacle_slowdown_factor(rx, ry)
            desired_vx *= obstacle_factor
            desired_vy *= obstacle_factor

            # Accel limiting (vx, vy, omega)
            now = self.get_clock().now()
            if self.last_cmd_time is None:
                dt = 0.1
            else:
                dt = (now - self.last_cmd_time).nanoseconds / 1e9
                if dt <= 0.0:
                    dt = 0.1
            self.last_cmd_time = now

            max_dvx = self.max_linear_accel * dt
            max_dvy = self.max_lateral_accel * dt
            max_domega = self.max_angular_accel * dt

            vx = max(self.last_v - max_dvx, min(self.last_v + max_dvx, desired_vx))
            vy = max(self.last_vy - max_dvy, min(self.last_vy + max_dvy, desired_vy))
            omega = max(self.last_omega - max_domega, min(self.last_omega + max_domega, desired_omega))

            self.last_v = vx
            self.last_vy = vy
            self.last_omega = omega

            twist = Twist()
            twist.linear.x = float(vx)
            twist.linear.y = float(vy)
            twist.angular.z = float(omega)

        else:
            # -------------- NON-HOLONOMIC --------------
            # Use your earlier diff-drive-like behavior:
            # forward/backwards (optional reversing) + yaw control

            desired_yaw = math.atan2(target_y - ry, target_x - rx)
            yaw_error = self.normalize_angle(desired_yaw - ryaw)

            reverse = False
            if self.allow_reversing:
                reverse_angle_threshold = 2.2
                if abs(yaw_error) > reverse_angle_threshold:
                    reverse = True
                    yaw_error = self.normalize_angle(yaw_error + math.pi)

            desired_omega = self.angular_gain * yaw_error
            desired_omega = max(-self.max_angular_speed, min(self.max_angular_speed, desired_omega))

            orientation_slowdown_distance = 0.8
            if dist_to_goal > orientation_slowdown_distance:
                heading_factor = 1.0
            else:
                heading_factor = max(0.0, math.cos(yaw_error))

            desired_v_mag = self.linear_gain * dist_to_goal * heading_factor
            desired_v_mag = max(0.0, min(self.max_linear_speed, desired_v_mag))

            if dist_to_goal > 1.0 and desired_v_mag > 0.0 and desired_v_mag < self.min_linear_speed:
                desired_v_mag = self.min_linear_speed

            desired_v = -desired_v_mag if reverse else desired_v_mag

            obstacle_factor = self.compute_obstacle_slowdown_factor(rx, ry)
            desired_v *= obstacle_factor

            now = self.get_clock().now()
            if self.last_cmd_time is None:
                dt = 0.1
            else:
                dt = (now - self.last_cmd_time).nanoseconds / 1e9
                if dt <= 0.0:
                    dt = 0.1
            self.last_cmd_time = now

            max_dv = self.max_linear_accel * dt
            max_domega = self.max_angular_accel * dt

            vx = max(self.last_v - max_dv, min(self.last_v + max_dv, desired_v))
            omega = max(self.last_omega - max_domega, min(self.last_omega + max_domega, desired_omega))

            # IMPORTANT: reset vy memory so it doesn't "carry over" when switching modes
            self.last_v = vx
            self.last_vy = 0.0
            self.last_omega = omega

            twist = Twist()
            twist.linear.x = float(vx)
            twist.linear.y = 0.0
            twist.angular.z = float(omega)

        if self.travel_start_time is None and (abs(twist.linear.x) > 1e-3 or abs(twist.linear.y) > 1e-3 or abs(twist.angular.z) > 1e-3):
            self.travel_start_time = self.get_clock().now()

        self.cmd_vel_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = SimpleController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()


