#!/usr/bin/env python3

import math
import heapq
import random

import rclpy
from rclpy.node import Node
from rclpy.time import Time

from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import OccupancyGrid, Path
import tf2_ros
from tf2_ros import TransformException


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


class SimpleGlobalPlanner(Node):
    """
    Global planner:
      - subscribes to /goal_point (PoseStamped in 'map')
      - uses TF to get robot pose in 'map'
      - subscribes to global costmap (OccupancyGrid)
      - runs A* with footprint
      - publishes nav_msgs/Path on /custom_plan
    """

    def __init__(self):
        super().__init__('simple_global_planner')

        # ----- Parameters -----
        self.declare_parameter('costmap_topic', '/global_costmap/costmap')
        self.declare_parameter('plan_topic', '/custom_plan')
        self.declare_parameter('lethal_cost', 100)
        self.declare_parameter('allow_unknown', False)
        self.declare_parameter('robot_radius', 0.45)    # m (approx half diagonal)
        self.declare_parameter('safety_margin', 0.05)   # m
        self.declare_parameter('enable_smoothing', True)
        self.declare_parameter('smoothing_iterations', 100)
        self.declare_parameter('smoothing_min_index_distance', 2)
        self.declare_parameter('smoothing_preserve_goal_points', 10)
        self.declare_parameter('planner_type', 'astar')  # 'astar' or 'dijkstra'

        self.costmap_topic = self.get_parameter('costmap_topic').value
        self.plan_topic = self.get_parameter('plan_topic').value
        self.lethal_cost = int(self.get_parameter('lethal_cost').value)
        self.allow_unknown = bool(self.get_parameter('allow_unknown').value)
        self.robot_radius = float(self.get_parameter('robot_radius').value)
        self.safety_margin = float(self.get_parameter('safety_margin').value)
        self.enable_smoothing = bool(self.get_parameter('enable_smoothing').value)
        self.smoothing_iterations = int(self.get_parameter('smoothing_iterations').value)
        self.smoothing_min_index_distance = int(self.get_parameter('smoothing_min_index_distance').value)
        self.smoothing_preserve_goal_points = int(self.get_parameter('smoothing_preserve_goal_points').value)
        self.planner_type = self.get_parameter('planner_type').value


        # ----- TF -----
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # ----- Costmap state -----
        self.costmap = None
        self.costmap_info = None
        self.costmap_received = False

        self.costmap_sub = self.create_subscription(
            OccupancyGrid,
            self.costmap_topic,
            self.costmap_callback,
            10
        )

        # ----- Goal subscription -----
        self.goal_sub = self.create_subscription(
            PoseStamped,
            '/goal_point',
            self.goal_callback,
            10
        )

        # ----- Path publisher -----
        self.plan_pub = self.create_publisher(Path, self.plan_topic, 10)

        self.get_logger().info(
            f'SimpleGlobalPlanner started. '
            f'Listening for /goal_point, costmap on "{self.costmap_topic}", '
            f'publishing Path on "{self.plan_topic}".'
        )

    # ---------- Costmap + helpers ----------

    def costmap_callback(self, msg: OccupancyGrid):
        self.costmap = list(msg.data)
        self.costmap_info = msg.info

        if not self.costmap_received:
            self.costmap_received = True
            w = msg.info.width
            h = msg.info.height
            res = msg.info.resolution
            ox = msg.info.origin.position.x
            oy = msg.info.origin.position.y
            self.get_logger().info(
                f'Costmap received on "{self.costmap_topic}": '
                f'{w}x{h} cells, res={res:.3f} m, origin=({ox:.3f}, {oy:.3f})'
            )

    def world_to_grid(self, x, y):
        if self.costmap_info is None:
            return None
        res = self.costmap_info.resolution
        w = self.costmap_info.width
        h = self.costmap_info.height
        origin = self.costmap_info.origin.position

        mx = int((x - origin.x) / res)
        my = int((y - origin.y) / res)
        if 0 <= mx < w and 0 <= my < h:
            return mx, my
        return None

    def grid_to_world(self, mx, my):
        if self.costmap_info is None:
            return None
        res = self.costmap_info.resolution
        origin = self.costmap_info.origin.position
        x = origin.x + (mx + 0.5) * res
        y = origin.y + (my + 0.5) * res
        return x, y

    def cost_at(self, mx, my):
        if self.costmap is None or self.costmap_info is None:
            return None
        w = self.costmap_info.width
        if not (0 <= mx < self.costmap_info.width and 0 <= my < self.costmap_info.height):
            return None
        idx = my * w + mx
        return self.costmap[idx]

    def is_cell_safe_for_robot(self, mx, my):
        """Check footprint disk around (mx, my)."""
        if self.costmap_info is None:
            return False

        res = self.costmap_info.resolution
        w = self.costmap_info.width
        h = self.costmap_info.height

        radius_m = self.robot_radius + self.safety_margin
        radius_cells = int(math.ceil(radius_m / res))

        for dx in range(-radius_cells, radius_cells + 1):
            for dy in range(-radius_cells, radius_cells + 1):
                nx = mx + dx
                ny = my + dy

                if not (0 <= nx < w and 0 <= ny < h):
                    return False

                if dx * dx + dy * dy > radius_cells * radius_cells:
                    continue

                c = self.cost_at(nx, ny)
                if c is None:
                    return False
                if c < 0 and not self.allow_unknown:
                    return False
                if c >= self.lethal_cost:
                    return False
        return True

    def is_cell_walkable(self, mx, my):
        c = self.cost_at(mx, my)
        if c is None:
            return False
        if c < 0 and not self.allow_unknown:
            return False
        if c >= self.lethal_cost:
            return False
        return self.is_cell_safe_for_robot(mx, my)
        
    def is_world_point_safe_for_robot(self, x, y):
        """
        Check if placing the robot's center at world coords (x,y) would be safe,
        using the same footprint-based check as A*.
        """
        cell = self.world_to_grid(x, y)
        if cell is None:
            return False
        mx, my = cell
        return self.is_cell_safe_for_robot(mx, my)

    def is_segment_collision_free(self, x0, y0, x1, y1):
        """
        Check if the straight line segment from (x0, y0) to (x1, y1)
        is free of collisions for the robot footprint.
        We sample points along the segment at roughly costmap resolution.
        """
        if self.costmap_info is None:
            return False

        res = self.costmap_info.resolution
        dx = x1 - x0
        dy = y1 - y0
        dist = math.hypot(dx, dy)
        if dist == 0.0:
            return self.is_world_point_safe_for_robot(x0, y0)

        # Sample along the segment every ~res/2 meters (a bit conservative)
        step = max(res * 0.5, 0.01)
        steps = int(dist / step)

        for i in range(steps + 1):
            t = i / max(steps, 1)
            x = x0 + t * dx
            y = y0 + t * dy
            if not self.is_world_point_safe_for_robot(x, y):
                return False

        return True
     

    # ---------- TF helper ----------

    def get_robot_pose_map(self):
        try:
            transform = self.tf_buffer.lookup_transform(
                'map', 'base_link', Time()
            )
        except TransformException as ex:
            self.get_logger().warn(f'Could not transform map -> base_link: {ex}')
            return None

        t = transform.transform.translation
        r = transform.transform.rotation
        x = t.x
        y = t.y
        yaw = yaw_from_quaternion(r)
        return x, y, yaw

    # ---------- A* ----------

    def neighbors(self, cell):
        (mx, my) = cell
        steps = [
            (1, 0, 1.0), (-1, 0, 1.0),
            (0, 1, 1.0), (0, -1, 1.0),
            (1, 1, math.sqrt(2.0)), (-1, 1, math.sqrt(2.0)),
            (1, -1, math.sqrt(2.0)), (-1, -1, math.sqrt(2.0)),
        ]
        w = self.costmap_info.width
        h = self.costmap_info.height
        for dx, dy, cost in steps:
            nx = mx + dx
            ny = my + dy
            if 0 <= nx < w and 0 <= ny < h:
                if self.is_cell_walkable(nx, ny):
                    yield (nx, ny), cost

    def heuristic(self, cell, goal):
        mx, my = cell
        gx, gy = goal
        return math.hypot(gx - mx, gy - my)

    def reconstruct_path(self, came_from, current):
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        path.reverse()
        return path

    def a_star(self, start, goal):
        if self.costmap_info is None or self.costmap is None:
            self.get_logger().warn('Cannot run A*: no costmap available.')
            return None, 0

        if not self.is_cell_walkable(*start):
            self.get_logger().warn(f'Start cell {start} is not walkable.')
            return None, 0

        if not self.is_cell_walkable(*goal):
            self.get_logger().warn(f'Goal cell {goal} is not walkable.')
            return None, 0

        open_set = []
        heapq.heappush(open_set, (0.0, start))

        came_from = {}
        g_score = {start: 0.0}

        visited = 0

        while open_set:
            _, current = heapq.heappop(open_set)
            visited += 1

            if current == goal:
                path = self.reconstruct_path(came_from, current)
                self.get_logger().info(
                    f'A* found a path with {len(path)} cells '
                    f'after expanding {visited} nodes.'
                )
                return path, visited

            for neighbor, move_cost in self.neighbors(current):
                c = self.cost_at(neighbor[0], neighbor[1])
                if c is None:
                    continue

                # costmap: 0..255 (unknown often -1)
                # If you allow_unknown is False, unknowns shouldn't appear here anyway.
                if c < 0:
                    continue

                cost_norm = min(max(float(c) / 255.0, 0.0), 1.0)
                W = 10.0  # tune 5..20

                tentative_g = g_score[current] + move_cost * (1.0 + W * cost_norm)

                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    if self.planner_type == 'dijkstra':
                        priority = tentative_g              # Dijkstra
                    else:
                        priority = tentative_g + self.heuristic(neighbor, goal)  # A*

                    heapq.heappush(open_set, (priority, neighbor))



        self.get_logger().warn(
            f'A* could not find a path from {start} to {goal} '
            f'(expanded {visited} nodes).'
        )
        return None, visited
        
    def smooth_path(self, path_world):
        """
        Apply shortcut smoothing to a path expressed in world coordinates.

        Input:
          path_world: list of (x, y)
        Output:
          new list of (x, y) (smoothed)
        """
        if len(path_world) <= 2:
            return path_world[:]  # nothing to smooth

        points = path_world[:]  # copy
        keep_tail = max(0, self.smoothing_preserve_goal_points)

        for _ in range(self.smoothing_iterations):
            n = len(points)
            
            # Need at least 2 endpoints + some points in between to shortcut
            if n <= 2 or n <= self.smoothing_min_index_distance + 1 + keep_tail:
                break
                
            # We only smooth indices in [0, n-1-keep_tail]
            # so last `keep_tail` points near the goal stay intact.
            tail_start_index = n - keep_tail if keep_tail > 0 else n
            if tail_start_index <= 1:
                break    

            max_i = tail_start_index - 1 - self.smoothing_min_index_distance
            if max_i < 0:
                break

            i = random.randint(0, max_i)
            j_min = i + self.smoothing_min_index_distance
            j_max = tail_start_index - 1
            if j_min >= j_max:
                continue  # nothing valid to choose

            j = random.randint(j_min, j_max)

            x0, y0 = points[i]
            x1, y1 = points[j]

            # If straight line between points[i] and points[j] is collision-free,
            # we can remove intermediate points.
            if self.is_segment_collision_free(x0, y0, x1, y1):
                # Keep everything up to i, then straight jump to j, then rest
                points = points[:i + 1] + points[j:]

        return points
    

    # ---------- Goal callback ----------

    def goal_callback(self, msg: PoseStamped):
        self.get_logger().info(
        f'Goal callback called! frame="{msg.header.frame_id}", '
        f'x={msg.pose.position.x:.3f}, y={msg.pose.position.y:.3f}'
        )
        frame = msg.header.frame_id
        gx = msg.pose.position.x
        gy = msg.pose.position.y
        goal_q = msg.pose.orientation
        goal_yaw = yaw_from_quaternion(goal_q)

        pose = self.get_robot_pose_map()
        if pose is None:
            self.get_logger().warn(
                f'Received goal in frame "{frame}" (x={gx:.3f}, y={gy:.3f}) '
                f'but robot pose is not available yet.'
            )
            return

        rx, ry, ryaw = pose

        if self.costmap_info is None:
            self.get_logger().warn('Costmap not received yet, cannot plan.')
            return

        start_cell = self.world_to_grid(rx, ry)
        goal_cell = self.world_to_grid(gx, gy)

        if start_cell is None or goal_cell is None:
            self.get_logger().warn(
                f'Either start {start_cell} or goal {goal_cell} is outside the costmap.'
            )
            return

        self.get_logger().info(
            f'Planning from start cell {start_cell} to goal cell {goal_cell} ...'
        )

        start_time = self.get_clock().now()
        path_cells, visited = self.a_star(start_cell, goal_cell)
        end_time = self.get_clock().now()
        planning_duration = (end_time - start_time).nanoseconds / 1e9

        if path_cells is None:
            self.get_logger().info(
                f'Planning failed after expanding {visited} nodes '
                f'in {planning_duration:.3f} s.'
            )
            return

        # Convert to world
        path_world = []
        for (mx, my) in path_cells:
            p = self.grid_to_world(mx, my)
            if p is not None:
                path_world.append(p)

        # Compute raw path length
        raw_length = 0.0
        for i in range(1, len(path_world)):
            x0, y0 = path_world[i - 1]
            x1, y1 = path_world[i]
            raw_length += math.hypot(x1 - x0, y1 - y0)

        # Decide which path to publish: smoothed or raw
        if self.enable_smoothing:
            path_for_msg = self.smooth_path(path_world)

            smoothed_length = 0.0
            for i in range(1, len(path_for_msg)):
                x0, y0 = path_for_msg[i - 1]
                x1, y1 = path_for_msg[i]
                smoothed_length += math.hypot(x1 - x0, y1 - y0)

            self.get_logger().info(
                f'Raw path: {len(path_world)} waypoints, length={raw_length:.2f} m. '
                f'Smoothed path: {len(path_for_msg)} waypoints, length={smoothed_length:.2f} m. '
                f'Planning_time={planning_duration:.3f} s, expanded_nodes={visited}.'
            )
        else:
            path_for_msg = path_world
            self.get_logger().info(
                f'Path has {len(path_world)} waypoints, length={raw_length:.2f} m, '
                f'planning_time={planning_duration:.3f} s, expanded_nodes={visited}.'
            )

        # Build nav_msgs/Path from path_for_msg
        path_msg = Path()
        path_msg.header.frame_id = 'map'
        path_msg.header.stamp = self.get_clock().now().to_msg()

        for i, (x, y) in enumerate(path_for_msg):
            pose_stamped = PoseStamped()
            pose_stamped.header = path_msg.header
            pose_stamped.pose.position.x = x
            pose_stamped.pose.position.y = y
            pose_stamped.pose.position.z = 0.0

            if i == len(path_for_msg) - 1:
                # last waypoint: use goal orientation
                pose_stamped.pose.orientation = goal_q
            else:
                # intermediate points: neutral orientation
                pose_stamped.pose.orientation.w = 1.0

            path_msg.poses.append(pose_stamped)

        self.plan_pub.publish(path_msg)

        # Preview first few waypoints
        if len(path_for_msg) > 0:
            preview = ', '.join(
                f'({x:.2f}, {y:.2f})' for (x, y) in path_for_msg[:5]
            )
            self.get_logger().info(
                f'First waypoints: {preview}{" ..." if len(path_for_msg) > 5 else ""}'
            )


def main(args=None):
    rclpy.init(args=args)
    node = SimpleGlobalPlanner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

