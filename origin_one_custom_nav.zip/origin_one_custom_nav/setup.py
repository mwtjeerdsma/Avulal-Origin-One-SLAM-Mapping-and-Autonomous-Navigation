from setuptools import find_packages, setup

package_name = 'origin_one_custom_nav'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='M. W. Tjeerdsma',
    maintainer_email='m.w.tjeerdsma@student.rug.nl',
    description='Custom path planner / controller for Avular Origin One',
    license='BSD-3-Clause',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'simple_planner = origin_one_custom_nav.simple_planner:main',
            'simple_global_planner = origin_one_custom_nav.simple_global_planner:main',
            'simple_controller = origin_one_custom_nav.simple_controller:main',
        ],
    },
)
