from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    SetLaunchConfiguration,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    set_world_file_name = SetLaunchConfiguration(
        "world", "sim_greenhouse.world"
    )
    robot_pose_x = SetLaunchConfiguration("robot_pose_x", "-6.0")
    robot_pose_y = SetLaunchConfiguration("robot_pose_y", "-9.675")
    robot_pose_yaw = SetLaunchConfiguration("robot_pose_yaw", "0.0")

    drive_configuration = DeclareLaunchArgument(
        "drive_configuration", default_value="skid_steer_drive")

    launch_origin_common = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [
                PathJoinSubstitution(
                    [
                        FindPackageShare("origin_one_gazebo"),
                        "launch",
                        "origin_sim_common.launch.py",
                    ]
                )
            ]
        ),
        launch_arguments={
            "drive_configuration": LaunchConfiguration("drive_configuration"),
            "world": LaunchConfiguration("world"),
            "robot_pose_x": LaunchConfiguration("robot_pose_x"),
            "robot_pose_y": LaunchConfiguration("robot_pose_y"),
            "robot_pose_yaw": LaunchConfiguration("robot_pose_yaw"),
        }.items(),
    )

    return LaunchDescription(
        [
            set_world_file_name,
            robot_pose_x,
            robot_pose_y,
            robot_pose_yaw,
            drive_configuration,
            launch_origin_common,
        ]
    )

