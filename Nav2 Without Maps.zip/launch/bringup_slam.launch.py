from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    nav2_bringup_dir = FindPackageShare("nav2_bringup").find("nav2_bringup")

    params_file = PathJoinSubstitution([
        FindPackageShare("origin_one_nav2"),
        "config",
        "nav2_params_slam.yaml",
    ])
    
    map_file = PathJoinSubstitution([
        FindPackageShare("origin_one_nav2"),
        "maps",
        "empty_map.yaml",
    ])

    slam_params_file = PathJoinSubstitution([
        FindPackageShare("origin_one_nav2"),
        "config",
        "origin_slam_params.yaml",
    ])

    bringup_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            nav2_bringup_dir,
            "/launch",
            "/bringup_launch.py",
        ]),
        launch_arguments={
            "slam": "True",
            "map": map_file,
            "use_sim_time": "True",
            "params_file": params_file,
            "slam_params_file": slam_params_file,
            # For SLAM mapping you do NOT need a prebuilt map argument.
            # (If you run localization mode later, you will pass "map:=...".)
        }.items(),
    )

    ekf_node = Node(
        package="robot_localization",
        executable="ekf_node",
        name="ekf_filter_node",
        output="screen",
        parameters=[PathJoinSubstitution([
            FindPackageShare("origin_one_nav2"),
            "config",
            "ekf.yaml",
        ])],
    )

    # Convert Ouster point cloud to 2D LaserScan for Nav2 / AMCL / slam_toolbox
    pcl_to_scan = Node(
        package="pointcloud_to_laserscan",
        executable="pointcloud_to_laserscan_node",
        name="pointcloud_to_laserscan",
        output="screen",
        parameters=[{
            "use_sim_time": True,
            "target_frame": "base_link",
            "transform_tolerance": 0.2,
            "min_height": 0.25,
            "max_height": 0.6,
            "range_min": 0.3,
            "range_max": 12.0,
        }],
        remappings=[
            ("cloud_in", "/robot/lidar/points"),
            ("scan", "/scan"),
        ],
    )

    return LaunchDescription([
        bringup_launch,
        ekf_node,
        pcl_to_scan,
    ])

