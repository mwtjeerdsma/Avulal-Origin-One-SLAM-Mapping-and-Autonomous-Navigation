from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    slam_params = PathJoinSubstitution([
        FindPackageShare("origin_one_nav2"),
        "config",
        "origin_slam_params.yaml",
    ])

    slam_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            FindPackageShare("slam_toolbox"),
            "/launch/online_async_launch.py",
        ]),
        launch_arguments={
            "slam_params_file": slam_params
        }.items(),
    )

    return LaunchDescription([slam_launch])

