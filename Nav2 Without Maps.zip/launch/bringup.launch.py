from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    nav2_bringup_dir = FindPackageShare("nav2_bringup").find("nav2_bringup")

    params_file = PathJoinSubstitution([
        FindPackageShare("origin_one_nav2"),
        "config",
        "nav2_params_minimal.yaml",
    ])

    map_file = PathJoinSubstitution([
        FindPackageShare("origin_one_nav2"),
        "maps",
        "Greenhouse_Vthree_safe.yaml",
    ])

    slam_params = PathJoinSubstitution([
        FindPackageShare("origin_one_nav2"),
        "config",
        "origin_slam_params.yaml",
    ])

    bringup_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            nav2_bringup_dir,
            "/launch",
            "/bringup_launch.py",
        ]),
        launch_arguments={
            "params_file": params_file,
            "map": map_file,        
            "slam": "False",          
            "use_sim_time": "True",
            "use_velocity_smoother": "False",
            "cmd_vel_topic": "/robot/cmd_vel"
           # "slam_params_file": slam_params,
        }.items(),
    )

    ekf_node = Node(
        package="robot_localization",
        executable="ekf_node",
        name="ekf_filter_node",
        output="screen",
        parameters=[PathJoinSubstitution([
            FindPackageShare("origin_one_nav2"),
            "config",
            "ekf.yaml",
        ])],
    )

    return LaunchDescription([bringup_launch, ekf_node])

