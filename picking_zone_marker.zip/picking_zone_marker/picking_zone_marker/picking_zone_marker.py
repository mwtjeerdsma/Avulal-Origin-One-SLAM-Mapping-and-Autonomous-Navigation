#!/usr/bin/env python3
import math

import rclpy
from rclpy.node import Node
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy


def circle_points(radius: float, n: int = 160):
    pts = []
    for i in range(n + 1):
        a = 2.0 * math.pi * i / n
        p = Point()
        p.x = radius * math.cos(a)
        p.y = radius * math.sin(a)
        p.z = 0.0
        pts.append(p)
    return pts


class PickingZoneMarker(Node):
    def __init__(self):
        super().__init__("picking_zone_marker")

        self.declare_parameter("frame_id", "base_link")
        self.declare_parameter("center_x", -0.10)
        self.declare_parameter("center_y",  0.00)
        self.declare_parameter("center_z",  0.20)

        self.declare_parameter("radius_outer", 0.70)
        self.declare_parameter("radius_inner", 0.50)  

        self.declare_parameter("line_width", 0.02)
        self.declare_parameter("rate_hz", 10.0)

        qos = QoSProfile(depth=10)
        qos.durability = DurabilityPolicy.VOLATILE
        qos.reliability = ReliabilityPolicy.RELIABLE

        self.frame_id = self.get_parameter("frame_id").value
        self.cx = float(self.get_parameter("center_x").value)
        self.cy = float(self.get_parameter("center_y").value)
        self.cz = float(self.get_parameter("center_z").value)

        self.r_outer = float(self.get_parameter("radius_outer").value)
        self.r_inner = float(self.get_parameter("radius_inner").value)

        self.line_width = float(self.get_parameter("line_width").value)
        rate_hz = float(self.get_parameter("rate_hz").value)

        self.pub = self.create_publisher(MarkerArray, "/picking_zone", qos)
        self.timer = self.create_timer(1.0 / rate_hz, self.tick)

        self.outer_pts = circle_points(self.r_outer)
        self.inner_pts = circle_points(self.r_inner)

    def make_ring(self, marker_id: int, pts, r, g, b, a=1.0):
        m = Marker()
        m.header.frame_id = self.frame_id
        m.header.stamp = self.get_clock().now().to_msg()

        m.ns = "picking_zone"
        m.id = marker_id
        m.type = Marker.LINE_STRIP
        m.action = Marker.ADD

        m.pose.position.x = self.cx
        m.pose.position.y = self.cy
        m.pose.position.z = self.cz
        m.pose.orientation.w = 1.0

        m.scale.x = self.line_width

        m.color.r = float(r)
        m.color.g = float(g)
        m.color.b = float(b)
        m.color.a = float(a)

        m.points = pts
        m.lifetime.sec = 0  # forever
        return m

    def tick(self):
        arr = MarkerArray()
        # Outer ring
        arr.markers.append(self.make_ring(
            marker_id=0,
            pts=self.outer_pts,
            r=1.0, g=0.0, b=0.0, a=1.0
        ))
        # Inner ring
        arr.markers.append(self.make_ring(
            marker_id=1,
            pts=self.inner_pts,
            r=0.0, g=1.0, b=0.0, a=1.0
        ))

        self.pub.publish(arr)


def main():
    rclpy.init()
    node = PickingZoneMarker()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

